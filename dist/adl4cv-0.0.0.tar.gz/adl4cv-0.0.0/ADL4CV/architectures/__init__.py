from .INRs import *
from .Hypernetworks import *