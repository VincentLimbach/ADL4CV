````markdown
# Project Overview

This repository contains the results of the joint research by Vincent Limbach and Leon Stadelmann conducted within the ADL4CV lecture. The project explores the creation of a merged neural field for object ensembles from the neural fields of individual objects. Our research defines two relevant generalization tasks and demonstrates that our approach successfully generalizes to unseen combinations and neural fields in 2D. For 3D, we show that while merging unseen combinations is feasible, handling unseen neural fields remains an open problem. This repository contains the relevant code from the final state of our internal project.

## Installation Instructions

To set up the project environment, follow these steps:

1. **Install Miniconda**:

   - Download and install Miniconda from the [official website](https://docs.conda.io/en/latest/miniconda.html) suitable for your operating system.

2. **Create Python Environment**:

   - Open a terminal or command prompt.
   - Create a new conda environment with Python 3.11.5:
     ```sh
     conda create -n ADL4CV python=3.11.5
     ```
   - Activate the environment:
     ```sh
     conda activate ADL4CV
     ```

3. **Install Project Dependencies**:
   - Navigate to the project directory.
   - Install the project using the setup script:
     ```sh
     python setup.py install
     ```

## Usage Guide

The main functionalities of the project are located in the following scripts:

- **2D Hypernetwork Trainer**: `ADL4CV/HypernetworkTrainer2D.py`
- **3D Hypernetwork Trainer**: `ADL4CV/HypernetworkTrainer3D.py`

### Running the Scripts

You can execute these scripts from the command line without any arguments to use the default values as described in the report. The scripts will calculate and store the final validation prediction in the `ADL4CV/evaluation/latest_run` directory.

- To run the 2D Hypernetwork Trainer:
  ```sh
  python ADL4CV/HypernetworkTrainer2D.py
  ```
````

- To run the 3D Hypernetwork Trainer:
  ```sh
  python ADL4CV/HypernetworkTrainer3D.py
  ```

### Customizing Hyperparameters

You can replace the default hyperparameters via the command line. To see an overview of the available options, use the `-h` flag:

- For the 2D Hypernetwork Trainer:

  ```sh
  python ADL4CV/HypernetworkTrainer2D.py -h
  ```

- For the 3D Hypernetwork Trainer:
  ```sh
  python ADL4CV/HypernetworkTrainer3D.py -h
  ```

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
